
// Main interactive behaviors: nav toggle and simple form handler
document.addEventListener('DOMContentLoaded', function(){
  const navToggle = document.getElementById('nav-toggle');
  const navLinks = document.getElementById('nav-links');

  if(navToggle){
    navToggle.addEventListener('click', function(){
      if(navLinks.style.display === 'block') navLinks.style.display = '';
      else navLinks.style.display = 'block';
    });
  }
});

function submitForm(e){
  e.preventDefault();
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const phone = document.getElementById('phone').value.trim();
  const service = document.getElementById('service-select').value;
  const brief = document.getElementById('brief').value.trim();

  // Simple client-side validation
  if(!name || !email){
    alert('Please enter name and email.');
    return;
  }

  // Create mailto link to send contents to site email
  const subject = encodeURIComponent('MakeMyDraft - New Brief from ' + name);
  const body = encodeURIComponent(
    'Name: ' + name + '\n' +
    'Email: ' + email + '\n' +
    'Phone: ' + phone + '\n' +
    'Service: ' + service + '\n\n' +
    'Brief:\n' + brief
  );
  const mailto = 'mailto:' + (window.MMD_DATA?.contact?.email || 'pankaj.md.pragmatic@gmail.com') + '?subject=' + subject + '&body=' + body;
  window.location.href = mailto;
}
