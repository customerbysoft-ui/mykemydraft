
// Loads data.json and exposes it as window.MMD_DATA for other scripts
(async function(){
  try {
    const res = await fetch('scripts/data.json');
    const data = await res.json();
    window.MMD_DATA = data;
    // populate services on pages if present
    function renderServicesGrid(){
      const grid = document.getElementById('services-grid');
      const list = document.getElementById('services-list');
      const preview = document.getElementById('services-preview');
      const select = document.getElementById('service-select');
      const heroTitle = document.getElementById('hero-title');
      const heroSubtitle = document.getElementById('hero-subtitle');
      const heroCta = document.getElementById('hero-cta');

      if(heroTitle) heroTitle.textContent = data.hero.title;
      if(heroSubtitle) heroSubtitle.textContent = data.hero.subtitle;
      if(heroCta) heroCta.textContent = data.hero.cta;

      if(grid){
        grid.innerHTML = '';
        data.services.forEach(s=>{
          const el = document.createElement('div');
          el.className = 'card';
          el.innerHTML = `<div class="service-title"><strong>${s.title}</strong></div><p class="muted">${s.desc}</p><div style="margin-top:10px"><a href="contact.html" class="btn outline">Request Draft</a></div>`;
          grid.appendChild(el);
        });
      }
      if(list){
        list.innerHTML = '';
        data.services.forEach(s=>{
          const el = document.createElement('div');
          el.className = 'card';
          el.innerHTML = `<h3>${s.title}</h3><p class="muted">${s.desc}</p><div style="margin-top:12px"><a href="contact.html" class="btn ghost">Request Draft</a></div>`;
          list.appendChild(el);
        });
      }
      if(select){
        select.innerHTML = '<option value="">Select service</option>';
        data.services.forEach(s=>{
          const opt = document.createElement('option');
          opt.value = s.title;
          opt.textContent = s.title;
          select.appendChild(opt);
        });
      }
    }
    renderServicesGrid();
  } catch(e){
    console.error('Failed to load site data', e);
  }
})();
